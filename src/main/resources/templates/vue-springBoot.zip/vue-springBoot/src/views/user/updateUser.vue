<template>
  <div>
      <h2>修改用户</h2>
      <el-form ref="form" :model="fromData" label-width="80px">
        <el-form-item label="id">
            <el-input v-model="fromData.id"></el-input>
        </el-form-item>
         <el-form-item label="姓名">
            <el-input v-model="fromData.username"></el-input>
        </el-form-item>
         <el-form-item label="密码">
            <el-input v-model="fromData.password"></el-input>
        </el-form-item>
         <el-form-item label="昵称">
            <el-input v-model="fromData.nickname"></el-input>
        </el-form-item>
         <el-form-item label="电话">
            <el-input v-model="fromData.telphone"></el-input>
        </el-form-item>
        <el-form-item label="地址">
            <el-input v-model="fromData.address"></el-input>
        </el-form-item>

        <el-form-item label="身份">
            <el-radio-group v-model="fromData.isAdmin">
            <el-radio :label="0" value="0">商家</el-radio>
            <el-radio :label="1" value="1">管理员</el-radio>
            </el-radio-group>
        </el-form-item>

        <el-form-item label="状态">
            <el-radio-group v-model="fromData.isDelete">
            <el-radio :label="1" value="1">注销</el-radio>
            <el-radio :label="0" value="0">正常</el-radio>
            </el-radio-group>
        </el-form-item>

        <el-form-item>
            <el-button type="primary" @click="onSubmit">提交</el-button>
            <el-button>取消</el-button>
        </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            fromData:{
                id:this.$route.params.id,
                username:"",
                password:"",
                nickname:"",
                telphone:"",
                address:"",
                isAdmin:"",
                isDelete:""
            }
        }
    },
    mounted() {
        const obj = this;
        obj.axios({
            method:"get",
            url:"http://localhost:8081/user/findById/"+this.fromData.id,
        }).then(function(respones){
            const ret = respones.data;
            if(ret.coode==1000){
                obj.fromData = ret.data
            }
        })
    },
    methods: {
        onSubmit(){
            const obj = this;
            this.axios({
                method:"post",
                url:"http://localhost:8081/user/modifyUser",
                data:this.fromData
            }).then(function(respones){
                const ret = respones.data;
                if(ret.coode==1000){
                    obj.$message({
                    message: '恭喜你，修改成功',
                    type: 'success'
                });

                // 延时跳转
                setTimeout(function(){
                obj.$router.push("/user/userList")
                },1000)
                }else{
                    obj.$message.error('错了哦，修改失败');
                }
            })
        }
    },
}
</script>

<style>
    div{
        text-align: center;
       
    }
    
   form{
       width: 600px;
        margin:0 auto
    }
</style>